package test;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.junit.Test;

import dao.ReserveDao;
import pojo.Reserve;

public class ReserveTest {
	@Test
	public void Test() throws ParseException {
		SimpleDateFormat sdf=new SimpleDateFormat("yyyyMMdd");
		SimpleDateFormat sdftime=new SimpleDateFormat("yyyy-MM-dd HH:mm");
		String stringdate=sdf.format(new Date());
		String adate=sdftime.format(new Date());
		System.out.println(stringdate);
		System.out.println(adate);
		//����һ��0-99�������
		Integer ran=(int) (Math.random()*999);
		System.out.println(ran);
		//����һ��
		String stringid=stringdate+"1"+ran;
		System.out.println(stringid);
	}
	@Test
	public void Sum() {
		String str1="123589415";
		String str2="498798524";
		Double i=Double.parseDouble(str1)+Double.parseDouble(str2);
		System.out.println(i);
	}
}
