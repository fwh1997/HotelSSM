package service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import dao.MaintainDao;
import pojo.Maintain;
import service.IMaintainService;
@Service
public class MaintainServiceImpl implements IMaintainService{
@Autowired
	MaintainDao maintainDao;
	@Override
	public List<Maintain> getMaintains() {
		return maintainDao.getMaintains();
	}

	@Override
	public Maintain getMaintainById(String id) {
		return maintainDao.getMaintainById(id);
	}

	@Override
	public int updateMaintainById(Maintain maintain) {
		return maintainDao.updateMaintainById(maintain);
	}

	@Override
	public int insertMaintain(Maintain maintain) {
		return maintainDao.insertMaintain(maintain);
	}

	@Override
	public int deleteMaintainById(String id) {
		return maintainDao.deleteMaintainById(id);
	}

}
