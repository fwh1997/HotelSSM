package service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import dao.StorageDao;
import pojo.Storage;
import service.IStorageService;
@Service
public class StorageServiceImpl implements IStorageService{
@Autowired
	StorageDao storageDao;
	@Override
	public List<Storage> getStorages() {
		return storageDao.getStorages();
	}

	@Override
	public Storage getStorageByName(String name) {
		return storageDao.getStorageByName(name);
	}

	@Override
	public int updateStorageByName(Storage storage) {
		return storageDao.updateStorageByName(storage);
	}

	@Override
	public int insertStorage(Storage storage) {
		return storageDao.insertStorage(storage);
	}

	@Override
	public int deleteStorageByName(String name) {
		return storageDao.deleteStorageByName(name);
	}

}
