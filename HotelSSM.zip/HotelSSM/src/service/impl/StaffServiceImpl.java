package service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import dao.StaffDao;
import pojo.Staff;
import service.IStaffService;
@Service
public class StaffServiceImpl implements IStaffService{
@Autowired
	StaffDao staffDao;
	@Override
	public List<Staff> getStaffs() {
		return staffDao.getStaffs();
	}

	@Override
	public Staff getStaffByName(String name) {
		return staffDao.getStaffByName(name);
	}

	@Override
	public int updateStaffByName(Staff staff) {
		return staffDao.updateStaffByName(staff);
	}

	@Override
	public int insertStaff(Staff staff) {
		return staffDao.insertStaff(staff);
	}

	@Override
	public int deleteStaffByName(String name) {
		return staffDao.deleteStaffByName(name);
	}

}
