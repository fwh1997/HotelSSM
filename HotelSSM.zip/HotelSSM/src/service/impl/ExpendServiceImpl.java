package service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import dao.ExpendDao;
import pojo.Expend;
import service.IExpendService;
@Service
public class ExpendServiceImpl implements IExpendService{
@Autowired
	ExpendDao expendDao;
	@Override
	public List<Expend> getExpends() {
		return expendDao.getExpends();
	}

	@Override
	public Expend getExpendById(String id) {
		return expendDao.getExpendById(id);
	}

	@Override
	public int updateExpendById(Expend expend) {
		return expendDao.updateExpendById(expend);
	}

	@Override
	public int insertExpend(Expend expend) {
		return expendDao.insertExpend(expend);
	}

	@Override
	public int deleteExpendById(String id) {
		return expendDao.deleteExpendById(id);
	}

}
