package service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import dao.IncomeDao;
import pojo.Income;
import service.IIncomeService;
@Service
public class IncomeServiceImpl implements IIncomeService{
@Autowired
	IncomeDao incomeDao;
	@Override
	public List<Income> getIncomes() {
		return incomeDao.getIncomes();
	}

	@Override
	public Income getIncomeById(String id) {
		return incomeDao.getIncomeById(id);
	}

	@Override
	public int updateIncomeById(Income income) {
		return incomeDao.updateIncomeById(income);
	}

	@Override
	public int insertIncome(Income income) {
		return incomeDao.insertIncome(income);
	}

	@Override
	public int deleteIncomeById(String id) {
		return incomeDao.deleteIncomeById(id);
	}

}
