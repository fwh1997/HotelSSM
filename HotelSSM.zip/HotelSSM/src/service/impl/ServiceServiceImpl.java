package service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import dao.ServiceDao;
import pojo.Service;
import service.IServiceService;
@org.springframework.stereotype.Service
public class ServiceServiceImpl implements IServiceService{
@Autowired
	ServiceDao serviceDao;
	@Override
	public List<Service> getServices() {
		return serviceDao.getServices();
	}

	@Override
	public Service getServiceById(String id) {
		return serviceDao.getServiceById(id);
	}

	@Override
	public int updateServiceById(Service service) {
		return serviceDao.updateServiceById(service);
	}

	@Override
	public int insertService(Service service) {
		return serviceDao.insertService(service);
	}

	@Override
	public int deleteServiceById(String id) {
		return serviceDao.deleteServiceById(id);
	}

}
