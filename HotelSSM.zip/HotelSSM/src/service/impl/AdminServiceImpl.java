package service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import dao.AdminDao;
import pojo.Admin;
import service.IAdminService;
@Service
public class AdminServiceImpl implements IAdminService{
@Autowired
	AdminDao adminDao;
	@Override
	public List<Admin> getAdmins() {
		return adminDao.getAdmins();
	}

	@Override
	public int insertAdmin(Admin admin) {
		return adminDao.insertAdmin(admin);
	}

	@Override
	public Admin getAdminByName(String name) {
		return adminDao.getAdminByName(name);
	}

	@Override
	public int updateAdminByName(Admin admin) {
		return adminDao.updateAdminByName(admin);
	}

	@Override
	public int deleteAdminByName(String name) {
		return adminDao.deleteAdminByName(name);
	}

	@Override
	public Admin loginAdmin(String name, String password) {
		return adminDao.loginAdmin(name, password);
	}

}
