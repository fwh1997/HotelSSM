package service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import dao.ReserveDao;
import pojo.Reserve;
import service.IReserveService;
@Service
public class ReserveServiceImpl implements IReserveService{
	@Autowired
	ReserveDao reserveDao;

	@Override
	public List<Reserve> getReserves() {
		return reserveDao.getReserves();
	}

	@Override
	public Reserve getReserveById(Integer id) {
		return reserveDao.getReserveById(id);
	}

	@Override
	public int updateReserve(Reserve reserve) {
		return reserveDao.updateReserve(reserve);
	}

	@Override
	public int insertReserve(Reserve reserve) {
		return reserveDao.insertReserve(reserve);
	}

	@Override
	public int deleteReserveById(Integer id) {
		return reserveDao.deleteReserveById(id);
	}

	@Override
	public int checkinChangeReserveStatus(Integer id) {
		return reserveDao.checkinChangeReserveStatus(id);
	}

}
