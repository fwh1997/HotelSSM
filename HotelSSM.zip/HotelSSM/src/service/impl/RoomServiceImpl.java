package service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import dao.RoomDao;
import pojo.Room;
import service.IRoomService;

@Service
public class RoomServiceImpl implements IRoomService{
	@Autowired
	RoomDao roomDao;
//��ѯ���з�����Ϣ
	@Override
	public List<Room> getRooms(){
		return roomDao.getRooms();
	}
//���ݷ���Ų�ѯĳ��������Ϣ
	@Override
	public Room getRoomByNum(Integer roomnum) {
		return roomDao.getRoomByNum(roomnum);
	}
//ɾ��ĳ������
	@Override
	public int deleteRoomByNum(Integer roomnum) {
		return roomDao.deleteRoomByNum(roomnum);
	}
//�޸�ĳ������
	@Override
	public int updateRoom(Room room) {
		return roomDao.updateRoom(room);
	}
//��������
	@Override
	public int insertRoom(Room room) {
		return roomDao.insertRoom(room);
	}
//�������ͻ�ȡ����
	@Override
	public List<Room> getRoomsByType(String roomtype) {
		return roomDao.getRoomsByType(roomtype);
}

	@Override
	public int checkoutRoomChangeRoom(Integer roomnum) {
		return roomDao.checkoutRoomChangeStatus(roomnum);
}
	@Override
	public int changeGuestOldRoom(Integer oldroom) {
		return roomDao.changeGuestOldRoom(oldroom);
	}
	@Override
	public int changeGuestNewRoom(Integer newroom) {
		// TODO Auto-generated method stub
		return roomDao.changeGuestNewRoom(newroom);
	}

}
