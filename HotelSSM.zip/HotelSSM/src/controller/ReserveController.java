package controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.annotation.JsonFormat;

import pojo.Reserve;
import service.IReserveService;
@JsonFormat(pattern="yyyy-MM-dd",timezone="GMT+8")
@Controller
public class ReserveController {
	@Autowired
	private IReserveService reserveService;
	//����Ԥ��
	@RequestMapping("/insertreserve")
	public String insertReserve(@ModelAttribute Reserve reserve){
			System.out.println(reserve);
			System.out.println("����Ԥ���ɹ�");
			reserveService.insertReserve(reserve);
			return "redirect:app/index.jsp";
	}
	//��ѯ����Ԥ��
	@RequestMapping("/getreserves")
	public String getReserves(Model model) {
		List<Reserve> reserves=reserveService.getReserves();
		model.addAttribute("reserve",reserves);
		System.out.println(reserves);
		return "admin/reserve";
	}
	
	//��Ӧҳ�����޸ĵ�
    @RequestMapping("/editreserve")
	@ResponseBody
	public Reserve getReserveById(Integer id,Model model) {
    	System.out.println(id);
		Reserve reserve=reserveService.getReserveById(id);
		//��Ҫ����id,���������棬IdΪnull
		model.addAttribute("id", id);
		System.out.println("��Ҫ�޸ĵ�Ԥ������"+id);
		return reserve;
	}
	//���²���
    @RequestMapping("/updatereservebyid")
    @ResponseBody
	public String updateReserveById(@ModelAttribute Reserve reserve) {
		System.out.println(reserve);
		if (reserveService.updateReserve(reserve)>0) {
			System.out.println("Ԥ����Ϣ�޸ĳɹ�");
			return "true";
		}else {
			return "false";
			}
	}
    //ɾ������
    @RequestMapping("/deletereservebyid")
    @ResponseBody
    public String deleteReserveById(Integer id) {
		System.out.println("ɾ��������Ԥ������"+id);
		if (reserveService.deleteReserveById(id)>0) {
			System.out.println("Ԥ��ɾ���ɹ�");
			return "true";
		}else {
			return "false";
		}
	}
}
