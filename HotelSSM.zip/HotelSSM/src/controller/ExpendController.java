package controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import pojo.Expend;
import service.IExpendService;

@Controller
public class ExpendController {
@Autowired
	private IExpendService expendService;
//��ѯ����֧��
	@RequestMapping("/getexpends")
	public String getExpends(Model model) {
		List<Expend> expends=expendService.getExpends();
		model.addAttribute("expend", expends);
		System.out.println(expends);
		return "admin/expend";
	}
	
	//����֧����
	@RequestMapping("/insertexpend")
	public String insertExpend(@ModelAttribute Expend expend) {
		System.out.println(expend);
		System.out.println("����֧���ɹ�");
		if (expendService.insertExpend(expend)>0) {
			return "true";
		}
		return "false";
	}
	//��Ӧҳ�����޸ĵ�
  @RequestMapping("/editexpend")
	@ResponseBody
	public Expend getExpendById(String id,Model model) {
  	System.out.println(id);
		Expend expend=expendService.getExpendById(id);
		//��Ҫ����id,���������棬IdΪnull
		model.addAttribute("id", id);
		System.out.println("��Ҫ�޸ĵ�֧������"+id);
		return expend;
	}
	//���²���
  @RequestMapping("/updateexpendbyid")
  @ResponseBody
	public String updateExpendById(@ModelAttribute Expend expend) {
		System.out.println(expend);
		if (expendService.updateExpendById(expend)>0) {
			System.out.println("֧����Ϣ�޸ĳɹ�");
			return "true";
		}else {
			return "false";
			}
	}
  //ɾ������
  @RequestMapping("/deleteexpendbyid")
  @ResponseBody
  public String deleteExpendById(String id) {
		System.out.println(id);
		if (expendService.deleteExpendById(id)>0) {
			return "true";
		}else {
			return "false";
		}
	}
}
