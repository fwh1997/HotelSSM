package controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import pojo.Room;
import service.IRoomService;

@Controller
public class RoomController {
	@Autowired
	private IRoomService roomService;
	//��ѯ����
	@RequestMapping("/getrooms")
	public String getRooms(Model model) {
		List<Room> rooms=roomService.getRooms();
		model.addAttribute("room",rooms);
		System.out.println(rooms);
		return "admin/room";
	}
    
	@RequestMapping("/")
	public String index() {
		return "forward:/getrooms";
	}
	
	//ɾ������
	@RequestMapping("/deleteroombynum")
	@ResponseBody
	public String deleteRoomByNum(Integer roomnum) {
		System.out.println(roomnum);
		if (roomService.deleteRoomByNum(roomnum)>0) {
			return "true";
		}else {
			return "false";
			}
	}
    //��Ӧҳ�����޸ĵ�
    @RequestMapping("/editroom")
	@ResponseBody
	public Room getRoomByNum(Integer roomnum,Model model) {
    	System.out.println(roomnum);
		Room room=roomService.getRoomByNum(roomnum);
		//��Ҫ����id,���������棬IdΪnull
		model.addAttribute("roomnum", roomnum);
		System.out.println("��Ҫ�޸ĵķ���"+room);
		return room;
	}
	//���²���
    @RequestMapping("/updateroombynum")
    @ResponseBody
	public String updateRoomByNum(@ModelAttribute Room room) {
		System.out.println(room);
		if (roomService.updateRoom(room)>0) {
			System.out.println("������Ϣ�޸ĳɹ�");
			return "true";
		}else {
			return "false";
			}
	}
    //��������
    @RequestMapping("/insertroom")
    @ResponseBody
    public String InsertRoom(@ModelAttribute Room room) {
		System.out.println(room);
		if (roomService.insertRoom(room)>0) {
			System.out.println("��������ɹ�");
			return "true";
		}else {
			return "false";
			}
	}
    //?????????
    //�������ͻ�ȡ����
    @RequestMapping("/getroomsbytype")
    @ResponseBody
    public List<Room> getRoomsByType(String roomtype,Model model) {
    	System.out.println(roomtype);
		List<Room> rooms=roomService.getRoomsByType(roomtype);
		model.addAttribute("room",rooms);
		System.out.println(rooms);
		return rooms;
	}
}
