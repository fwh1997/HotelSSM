package controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import pojo.Staff;
import service.IStaffService;

@Controller
public class StaffController {
	@Autowired
	private IStaffService staffService;
	//��ѯ����
	@RequestMapping("/getsatffs")
	public String getStaffs(Model model) {
		List<Staff> staffs=staffService.getStaffs();
		model.addAttribute("staff", staffs);
		System.out.println(staffs);
		return "admin/staff";
	}
	//ɾ������
	@RequestMapping("/deletestaffbyname")
	@ResponseBody
	public String deleteStaffByName(String name) {
		System.out.println("ɾ����Ա������"+name);
		if (staffService.deleteStaffByName(name)>0) {
			return "true";
		}else {
			return "false";
		}
	}
	
	//��Ӧ�޸Ĳ���
	@RequestMapping("editstaff")
	@ResponseBody
	public Staff getSatffByName(String name,Model model) {
		System.out.println("��Ҫ�޸ĵ�Ա����"+name);
		Staff staff=staffService.getStaffByName(name);
		model.addAttribute("name",name);
		return staff;
	}
	
	//���²���
	@RequestMapping("/updatestaffbyname")
	@ResponseBody
	public String updateStaffByName(@ModelAttribute Staff staff) {
		System.out.println("����Ա����"+staff);
		if (staffService.updateStaffByName(staff)>0) {
			return "true";
		}else {
			return "false";
		}
	}
	
	//��������
	@RequestMapping("/insertstaff")
	public String insertStaff(@ModelAttribute Staff staff) { 
		System.out.println("����Ա����"+staff);
		if (staffService.insertStaff(staff)>0) {
			return "true";
		}else {
			return "false";
		}
	}
}
