package controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import pojo.Income;
import service.IIncomeService;

@Controller
public class IncomeController {
	@Autowired
	private IIncomeService incomeService;
	//��ѯ��������
	@RequestMapping("/getincomes")
	public String getIncomes(Model model) {
		List<Income> incomes=incomeService.getIncomes();
		model.addAttribute("income", incomes);
		System.out.println(incomes);
		return "admin/income";
	}
	
	//���������
	@RequestMapping("/insertincome")
	public String insertIncome(@ModelAttribute Income income) {
		System.out.println(income);
		System.out.println("��������ɹ�");
		if (incomeService.insertIncome(income)>0) {
			return "true";
		}
		return "false";
	}
	//��Ӧҳ�����޸ĵ�
    @RequestMapping("/editincome")
	@ResponseBody
	public Income getIncomeById(String id,Model model) {
    	System.out.println(id);
		Income income=incomeService.getIncomeById(id);
		//��Ҫ����id,���������棬IdΪnull
		model.addAttribute("id", id);
		System.out.println("��Ҫ�޸ĵ����뵥��"+id);
		return income;
	}
	//���²���
    @RequestMapping("/updateincomebyid")
    @ResponseBody
	public String updateIncomeById(@ModelAttribute Income income) {
		System.out.println(income);
		if (incomeService.updateIncomeById(income)>0) {
			System.out.println("Ԥ����Ϣ�޸ĳɹ�");
			return "true";
		}else {
			return "false";
			}
	}
    //ɾ������
    @RequestMapping("/deleteincomebyid")
    @ResponseBody
    public String deleteIncomeById(String id) {
		System.out.println(id);
		if (incomeService.deleteIncomeById(id)>0) {
			return "true";
		}else {
			return "false";
		}
	}
}
