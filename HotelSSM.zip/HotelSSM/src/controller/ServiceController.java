package controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import pojo.Service;
import service.IServiceService;

@Controller
public class ServiceController {
@Autowired
private IServiceService serviceService;
	//��ѯ���з���
	@RequestMapping("/getservices")
	public String getServices(Model model) {
		List<Service> services=serviceService.getServices();
		model.addAttribute("service", services);
		System.out.println(services);
		return "admin/service";
	}
	//��������
	@RequestMapping("/insertservice")
	public String insertService(@ModelAttribute Service service) {
		System.out.println(service);
		System.out.println("�½�����ɹ�");
		if (serviceService.insertService(service)>0) {
			return "true";
		}else {
			return "false";
		}
	}
	//��Ӧҳ�����޸ĵ�
    @RequestMapping("/editservice")
	@ResponseBody
	public Service getServiceById(String id,Model model) {
    	System.out.println(id);
    	Service service=serviceService.getServiceById(id);
		//��Ҫ����id,���������棬IdΪnull
		model.addAttribute("id", id);
		System.out.println("��Ҫ�޸ĵķ��񵥺�"+id);
		return service;
	}
	//���²���
    @RequestMapping("/updateservicebyid")
    @ResponseBody
	public String updateServiceById(@ModelAttribute Service service) {
		System.out.println(service);
		if (serviceService.updateServiceById(service)>0) {
			System.out.println("�ͷ�������Ϣ�޸ĳɹ�");
			return "true";
		}else {
			return "false";
			}
	}
    //ɾ������
    @RequestMapping("/deleteservicebyid")
    @ResponseBody
    public String deleteServiceById(String id) {
		System.out.println(id);
		if (serviceService.deleteServiceById(id)>0) {
			return "true";
		}else {
			return "false";
		}
	}
}
