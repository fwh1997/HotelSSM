package controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import pojo.Maintain;
import service.IMaintainService;

@Controller
public class MaintainController {
@Autowired
	private IMaintainService maintainService;
	
//��ѯ��������
	@RequestMapping("/getmaintains")
	public String getMaintains(Model model) {
		List<Maintain> maintains=maintainService.getMaintains();
		model.addAttribute("maintain", maintains);
		System.out.println(maintains);
		return "admin/maintain";
	}
	
	//����ά����
	@RequestMapping("/insertmaintain")
	public String insertMaintain(@ModelAttribute Maintain maintain) {
		System.out.println(maintain);
		System.out.println("����ά���ɹ�");
		if (maintainService.insertMaintain(maintain)>0) {
			return "true";
		}
		return "false";
	}
	//��Ӧҳ�����޸ĵ�
  @RequestMapping("/editmaintain")
	@ResponseBody
	public Maintain getMaintainById(String id,Model model) {
  		System.out.println(id);
		Maintain maintain=maintainService.getMaintainById(id);
		//��Ҫ����id,���������棬IdΪnull
		model.addAttribute("id", id);
		System.out.println("��Ҫ�޸ĵ�ά������"+id);
		return maintain;
	}
	//���²���
  @RequestMapping("/updatemaintainbyid")
  @ResponseBody
	public String updateMaintainById(@ModelAttribute Maintain maintain) {
		System.out.println(maintain);
		if (maintainService.updateMaintainById(maintain)>0) {
			System.out.println("ά����Ϣ�޸ĳɹ�");
			return "true";
		}else {
			return "false";
			}
	}
  //ɾ������
  @RequestMapping("/deletemaintainbyid")
  @ResponseBody
  public String deleteMaintainById(String id) {
		System.out.println(id);
		if (maintainService.deleteMaintainById(id)>0) {
			return "true";
		}else {
			return "false";
		}
	}
}
