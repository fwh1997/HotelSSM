package controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import pojo.Storage;
import service.IStorageService;

@Controller
public class StorageController {
@Autowired
	private IStorageService storageService;
	//��ѯ���вִ���Ϣ
	@RequestMapping("/getstorages")
	public String getStorages(Model model) {
		List<Storage> storages=storageService.getStorages();
		model.addAttribute("storage", storages);
		System.out.println(storages);
		return "admin/storage";
	}
	
	//������
	@RequestMapping("/insertstorage")
	public String insertStorage(@ModelAttribute Storage storage) {
		System.out.println(storage);
		System.out.println("��������ɹ�");
		if (storageService.insertStorage(storage)>0) {
			return "true";
		}
		return "false";
	}
	//��Ӧҳ�����޸ĵ�
  @RequestMapping("/editstorage")
	@ResponseBody
	public Storage getStorageByName(String name,Model model) {
  	System.out.println(name);
  	Storage storage=storageService.getStorageByName(name);
		//��Ҫ����id,���������棬IdΪnull
		model.addAttribute("name", name);
		System.out.println("��Ҫ�޸ĵ���Ʒ"+name);
		return storage;
	}
	//���²���
  @RequestMapping("/updatestoragebyname")
  @ResponseBody
	public String updateStorageByName(@ModelAttribute Storage storage) {
		System.out.println(storage);
		if (storageService.updateStorageByName(storage)>0) {
			System.out.println("�ִ���Ϣ�޸ĳɹ�");
			return "true";
		}else {
			return "false";
			}
	}
  //ɾ������
  @RequestMapping("/deletestoragebyname")
  @ResponseBody
  public String deleteStorageByName(String name) {
		System.out.println(name);
		if (storageService.deleteStorageByName(name)>0) {
			return "true";
		}else {
			return "false";
		}
	}
}
