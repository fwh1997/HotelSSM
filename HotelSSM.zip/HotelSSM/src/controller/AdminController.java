package controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import pojo.Admin;
import service.IAdminService;

@Controller
public class AdminController {
	@Autowired
	private IAdminService adminService;
	//��ѯ���й���Ա
		@RequestMapping("/getadmins")
		public String getAdmins(Model model) {
			List<Admin> admins=adminService.getAdmins();
			model.addAttribute("admin", admins);
			System.out.println(admins);
			return "admin/admin";
		}
		
		//����֧����
		@RequestMapping("/insertadmin")
		public String insertAdmin(@ModelAttribute Admin admin) {
			System.out.println(admin);
			System.out.println("����һ������Ա�ɹ�");
			if (adminService.insertAdmin(admin)>0) {
				return "true";
			}
			return "false";
		}
		//��Ӧҳ�����޸ĵ�
	  @RequestMapping("/editadmin")
		@ResponseBody
		public Admin getAdminByName(String name,Model model) {
	  	System.out.println(name);
			Admin admin=adminService.getAdminByName(name);
			//��Ҫ����id,���������棬IdΪnull
			model.addAttribute("name", name);
			System.out.println("��Ҫ�޸ĵĹ���Ա"+name);
			return admin;
		}
		//���²���
	  @RequestMapping("/updateadminbyname")
	  @ResponseBody
		public String updateAdminByName(@ModelAttribute Admin admin) {
			System.out.println(admin);
			if (adminService.updateAdminByName(admin)>0) {
				System.out.println("����Ա��Ϣ�޸ĳɹ�");
				return "true";
			}else {
				return "false";
				}
		}
	  //ɾ������
	  @RequestMapping("/deleteadminbyname")
	  @ResponseBody
	  public String deleteAdminByName(String name) {
			System.out.println(name);
			if (adminService.deleteAdminByName(name)>0) {
				return "true";
			}else {
				return "false";
			}
		}
	  
	  //��¼��֤
	@RequestMapping("/loginadmin")
	  public String loginAdmin(HttpSession session,String name,String password,Admin admin) {
		  System.out.println(name+"---"+password);
		  if (adminService.loginAdmin(name, password)!=null) {
			  session.setAttribute("adminname", name);
			return "redirect:admin/index.jsp";
		}else {
			return "redirect:admin/error.jsp";
		}
	  }
	//�˳���¼
	@RequestMapping("/exitlogin")
	public String exitLogin(HttpSession session) {
		session.removeAttribute("adminname");
		System.out.println("��¼�����session����ɹ�������");
		return "redirect:admin/login.jsp";
	}
}
