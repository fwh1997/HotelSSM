package pojo;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

public class Reserve {
	private int id;
	private String name;
	private String phone;
	private String roomtype;
	@DateTimeFormat(pattern="yyyy-MM-dd")
	private Date arraytime;
	@DateTimeFormat(pattern="yyyy-MM-dd")
	private Date leavetime;
	private String status;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getRoomtype() {
		return roomtype;
	}
	public void setRoomtype(String roomtype) {
		this.roomtype = roomtype;
	}
	public Date getArraytime() {
		return arraytime;
	}
	public void setArraytime(Date arraytime) {
		this.arraytime = arraytime;
	}
	public Date getLeavetime() {
		return leavetime;
	}
	public void setLeavetime(Date leavetime) {
		this.leavetime = leavetime;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Reserve(int id, String name, String phone, String roomtype, Date arraytime, Date leavetime) {
		super();
		this.id = id;
		this.name = name;
		this.phone = phone;
		this.roomtype = roomtype;
		this.arraytime = arraytime;
		this.leavetime = leavetime;
	}
	public Reserve() {
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Reserve [id=" + id + ", name=" + name + ", phone=" + phone + ", roomtype=" + roomtype + ", arraytime="
				+ arraytime + ", leavetime=" + leavetime + ", status=" + status + "]";
	}

}
