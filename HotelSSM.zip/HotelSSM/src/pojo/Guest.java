package pojo;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

public class Guest {
	private int id;
	private String name;
	private String idnum;
	private int roomnum;
	private String phone;
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm")
	private Date arraytime;
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm")
	private Date leavetime;
	private int receivable;
	private int deposit;
	private String remark;
	private String status;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getIdnum() {
		return idnum;
	}
	public void setIdnum(String idnum) {
		this.idnum = idnum;
	}
	public int getRoomnum() {
		return roomnum;
	}
	public void setRoomnum(int roomnum) {
		this.roomnum = roomnum;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public Date getArraytime() {
		return arraytime;
	}
	public void setArraytime(Date arraytime) {
		this.arraytime = arraytime;
	}
	public Date getLeavetime() {
		return leavetime;
	}
	public void setLeavetime(Date leavetime) {
		this.leavetime = leavetime;
	}
	public int getReceivable() {
		return receivable;
	}
	public void setReceivable(int receivable) {
		this.receivable = receivable;
	}
	public int getDeposit() {
		return deposit;
	}
	public void setDeposit(int deposit) {
		this.deposit = deposit;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	} 
	@Override
	public String toString() {
		return "guest [id=" + id + ", name=" + name + ", idnum=" + idnum + ", roomnum=" + roomnum + ", phone=" + phone
				+ ", arraytime=" + arraytime + ", leavetime=" + leavetime + ", receivable=" + receivable + ", deposit="
				+ deposit + ", remark=" + remark +  ", status=" + status + "]";
	}
	public Guest(int id, String name, String idnum, int roomnum, String phone, Date arraytime, Date leavetime,
			int receivable, int deposit, String remark,String status) {
		super();
		this.id = id;
		this.name = name;
		this.idnum = idnum;
		this.roomnum = roomnum;
		this.phone = phone;
		this.arraytime = arraytime;
		this.leavetime = leavetime;
		this.receivable = receivable;
		this.deposit = deposit;
		this.remark = remark;
		this.status=status;
	}
	public Guest() {
		// TODO Auto-generated constructor stub
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
}
