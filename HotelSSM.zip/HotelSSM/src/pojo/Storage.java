package pojo;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

public class Storage {
	private String name;
	private int number;
	private String detail;
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm")
	private Date lasttime;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getNumber() {
		return number;
	}
	public void setNumber(int number) {
		this.number = number;
	}
	public String getDetail() {
		return detail;
	}
	public void setDetail(String detail) {
		this.detail = detail;
	}
	public Date getLasttime() {
		return lasttime;
	}
	public void setLasttime(Date lasttime) {
		this.lasttime = lasttime;
	}
	@Override
	public String toString() {
		return "Storage [name=" + name + ", number=" + number + ", detail=" + detail + ", lasttime=" + lasttime + "]";
	}
	
}
