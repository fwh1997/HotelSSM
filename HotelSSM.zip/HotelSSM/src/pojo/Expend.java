package pojo;

public class Expend {
	private String id;
	private String expendname;
	private String detail;
	private int money;
	private String operator;
	private String remark;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getExpendname() {
		return expendname;
	}
	public void setExpendname(String expendname) {
		this.expendname = expendname;
	}
	public int getMoney() {
		return money;
	}
	public void setMoney(int money) {
		this.money = money;
	}
	public String getOperator() {
		return operator;
	}
	public void setOperator(String operator) {
		this.operator = operator;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getDetail() {
		return detail;
	}
	public void setDetail(String detail) {
		this.detail = detail;
	}
	@Override
	public String toString() {
		return "Income [id=" + id + ", expendname=" + expendname + ", detail=" + detail + ", money=" + money
				+ ", operator=" + operator + ", remark=" + remark + "]";
	}
}
