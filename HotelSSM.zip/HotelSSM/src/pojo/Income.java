package pojo;

public class Income {
	private String id;
	private String incomename;
	private String detail;
	private int money;
	private String operator;
	private String remark;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getIncomename() {
		return incomename;
	}
	public void setIncomename(String incomename) {
		this.incomename = incomename;
	}
	public int getMoney() {
		return money;
	}
	public void setMoney(int money) {
		this.money = money;
	}
	public String getOperator() {
		return operator;
	}
	public void setOperator(String operator) {
		this.operator = operator;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getDetail() {
		return detail;
	}
	public void setDetail(String detail) {
		this.detail = detail;
	}
	@Override
	public String toString() {
		return "Income [id=" + id + ", incomename=" + incomename + ", detail=" + detail + ", money=" + money
				+ ", operator=" + operator + ", remark=" + remark + "]";
	}
}
