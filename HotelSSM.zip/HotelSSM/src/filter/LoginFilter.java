package filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class LoginFilter implements Filter{
	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		// TODO Auto-generated method stub
		Filter.super.init(filterConfig);
	}
	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		//��¼ҳ�治�ù���
		 	HttpServletRequest servletRequest = (HttpServletRequest) request;
	        HttpServletResponse servletResponse = (HttpServletResponse) response;
	        HttpSession session = servletRequest.getSession();
	        // ����û������URI
	        String path = servletRequest.getRequestURI();
	        //System.out.println(path); 
	        // ��session��ȡԱ��������Ϣ
	        String name = (String) session.getAttribute("adminname");
	        //��¼���������ص���
	        //path.equals("/HotelSSM/admin/index.jsp")||
		if (path.equals("/HotelSSM/admin/login.jsp")||path.equals("/HotelSSM/loginadmin")) {
			System.out.println(path);
			System.out.println(name);
			chain.doFilter(servletRequest, servletResponse);
			return;
		}
		//sessionû������ �Ǿ���û��¼
		if (name==null||"".equals(name)) {
			System.out.println(name);
			//��ת��¼
			if (path.equals("/HotelSSM/admin/index.jsp")) {
				System.out.println("������a��ǩֱ����ת");
				servletResponse.sendRedirect("login.jsp");
				//�ֶ��жϰ�...��������λ���޸����û����ֻᱻ����
			}else if(path.equals("/HotelSSM/getrooms")||path.equals("/HotelSSM/getstaffs")||path.equals("/HotelSSM/getadmins")||path.equals("/HotelSSM/getreserves")){
				System.out.println("�����˷���֮�����ת");
				servletResponse.sendRedirect("admin/login.jsp");
			}

		}else {
			chain.doFilter(servletRequest, servletResponse);
		}
		
	}
	@Override
	public void destroy() {
		// TODO Auto-generated method stub
		Filter.super.destroy();
	}

}
